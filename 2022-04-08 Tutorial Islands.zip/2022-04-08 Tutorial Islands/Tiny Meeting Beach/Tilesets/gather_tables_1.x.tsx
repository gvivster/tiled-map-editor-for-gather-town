<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Gather Tables 1.x" tilewidth="32" tileheight="32" tilecount="9000" columns="90">
 <image source="gather_tables_2.1.png" width="2880" height="3200"/>
</tileset>
