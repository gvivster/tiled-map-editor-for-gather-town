<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Gather Walls+Roofs Exterior 2.x" tilewidth="32" tileheight="32" tilecount="31200" columns="156">
 <image source="gather_exterior_walls_2.1.png" width="4992" height="6400"/>
</tileset>
