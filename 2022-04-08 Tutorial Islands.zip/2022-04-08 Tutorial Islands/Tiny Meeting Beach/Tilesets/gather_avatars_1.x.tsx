<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Gather Avatars 1.x" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="gather_avatars_1.0.png" width="256" height="256"/>
</tileset>
