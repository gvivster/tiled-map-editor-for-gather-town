<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Gather Shadows 1.x" tilewidth="32" tileheight="32" tilecount="200" columns="10">
 <image source="gather_shadows_1.1.png" width="320" height="640"/>
</tileset>
