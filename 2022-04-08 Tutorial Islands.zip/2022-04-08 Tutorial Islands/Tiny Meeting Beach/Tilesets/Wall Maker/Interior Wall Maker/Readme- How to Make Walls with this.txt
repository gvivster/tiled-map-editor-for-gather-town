The purpose of these files is to allow you to quickly layer a wall texture and trims and export a fully functional wallset to add to your tilesheet.

Step one: Edit "CHANGE THIS FOR NEW WALL"
- Replace The blank wall textures. See "annotated sheet" For guidance as to what tiles do what.
- Save your work.

Step 2: Open Wall Maker.tmx in Tiled.
- View your work and make any changes you want to make.
- Save your work as an image.

You now have a set that can be added to a tilesheet.