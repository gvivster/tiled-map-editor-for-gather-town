<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="WallsetCyberpunk" tilewidth="32" tileheight="32" tilecount="225" columns="25">
 <image source="../../../objects/WIP/13/Cyberpunk/WallsetCyberpunk2.png" width="800" height="288"/>
</tileset>
