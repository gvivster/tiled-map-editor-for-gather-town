<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Wall Maker" tilewidth="32" tileheight="32" tilecount="700" columns="25">
 <image source="CHANGE THIS FOR NEW WALL.png" width="800" height="912"/>
</tileset>
