<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.0" name="Gather Decoration Exterior" tilewidth="32" tileheight="32" tilecount="5200" columns="40">
 <image source="gather_decoration_exterior_1.3.png" width="1280" height="4160"/>
</tileset>
