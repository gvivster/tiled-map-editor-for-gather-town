<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="trimsanddoors" tilewidth="32" tileheight="32" tilecount="750" columns="15">
 <image source="trimsanddoors.png" width="480" height="1600"/>
</tileset>
