<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="walltexture" tilewidth="32" tileheight="32" tilecount="1920" columns="24">
 <image source="walltexture.png" width="768" height="2560"/>
</tileset>
