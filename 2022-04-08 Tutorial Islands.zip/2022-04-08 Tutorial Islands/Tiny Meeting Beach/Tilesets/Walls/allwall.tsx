<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="allwall" tilewidth="32" tileheight="32" tilecount="1824" columns="24">
 <image source="allwall.png" width="768" height="2432"/>
</tileset>
