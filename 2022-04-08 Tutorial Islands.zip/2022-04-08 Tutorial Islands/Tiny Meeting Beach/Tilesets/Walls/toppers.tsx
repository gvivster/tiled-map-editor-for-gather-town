<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="toppers" tilewidth="32" tileheight="32" tilecount="612" columns="17">
 <image source="toppers.png" width="544" height="1152"/>
</tileset>
