<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Gather Chairs" tilewidth="32" tileheight="32" tilecount="650" columns="25">
 <image source="gather_chairs_1.3.png" width="800" height="832"/>
</tileset>
