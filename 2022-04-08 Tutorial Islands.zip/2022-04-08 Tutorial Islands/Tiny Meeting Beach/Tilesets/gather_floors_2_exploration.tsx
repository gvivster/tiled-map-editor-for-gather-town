<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="gather_floors_2_exploration" tilewidth="32" tileheight="32" tilecount="8160" columns="60">
 <image source="gather_floors_2_exploration.png" width="1920" height="4352"/>
</tileset>
