<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Gather Games 1.x" tilewidth="32" tileheight="32" tilecount="600" columns="20">
 <image source="gather_games_1.1.png" width="640" height="960"/>
</tileset>
