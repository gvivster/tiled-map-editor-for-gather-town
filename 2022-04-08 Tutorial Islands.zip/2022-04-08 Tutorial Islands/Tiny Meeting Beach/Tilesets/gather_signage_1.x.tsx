<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="gather_signage_0.1" tilewidth="32" tileheight="32" tilecount="3192" columns="40">
 <image source="gather_signage_1.2.png" width="1280" height="1889"/>
</tileset>
