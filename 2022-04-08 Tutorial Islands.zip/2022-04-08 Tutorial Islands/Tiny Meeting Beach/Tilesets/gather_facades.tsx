<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="gater_facades" tilewidth="32" tileheight="32" tilecount="5256" columns="72">
 <image source="gather_facade_elements_1.0.png" width="2304" height="2336"/>
</tileset>
