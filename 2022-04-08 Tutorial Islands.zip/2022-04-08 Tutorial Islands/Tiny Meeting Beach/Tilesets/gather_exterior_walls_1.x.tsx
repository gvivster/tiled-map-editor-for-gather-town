<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Gather Walls Exterior 1.x" tilewidth="32" tileheight="32" tilecount="31200" columns="43">
 <image source="gather_exterior_walls_1.0.png" width="1400" height="1600"/>
</tileset>
