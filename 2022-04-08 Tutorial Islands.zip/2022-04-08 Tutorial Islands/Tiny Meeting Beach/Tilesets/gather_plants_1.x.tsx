<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Gather Plants 1.x" tilewidth="32" tileheight="32" tilecount="800" columns="20">
 <image source="gather_plants_1.2.png" width="640" height="1280"/>
 <terraintypes>
  <terrain name="hedges (hollow)" tile="635"/>
  <terrain name="hedges (square filled)" tile="635"/>
 </terraintypes>
 <tile id="614" terrain=",,,1"/>
 <tile id="615" terrain=",,1,1"/>
 <tile id="616" terrain=",,1,"/>
 <tile id="634" terrain=",1,,1"/>
 <tile id="635" terrain="1,1,1,1"/>
 <tile id="636" terrain="1,,1,"/>
 <tile id="638" terrain="0,0,0,"/>
 <tile id="639" terrain="0,0,,0"/>
 <tile id="650" terrain=",,,0"/>
 <tile id="651" terrain=",,0,0"/>
 <tile id="652" terrain=",,0,"/>
 <tile id="654" terrain=",1,,"/>
 <tile id="655" terrain="1,1,,"/>
 <tile id="656" terrain="1,,,"/>
 <tile id="658" terrain="0,,0,0"/>
 <tile id="659" terrain=",0,0,0"/>
 <tile id="670" terrain=",0,,0"/>
 <tile id="671" terrain="0,0,0,0"/>
 <tile id="672" terrain="0,,0,"/>
 <tile id="677" terrain="1,1,1,"/>
 <tile id="678" terrain="1,1,,1"/>
 <tile id="690" terrain=",0,,"/>
 <tile id="691" terrain="0,0,,"/>
 <tile id="692" terrain="0,,,"/>
 <tile id="697" terrain="1,,1,1"/>
 <tile id="698" terrain=",1,1,1"/>
</tileset>
