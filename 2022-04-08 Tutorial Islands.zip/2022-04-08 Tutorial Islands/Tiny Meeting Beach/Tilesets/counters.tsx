<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="counters" tilewidth="32" tileheight="32" tilecount="5500" columns="50">
 <image source="../objects/uploaded/furniture/table/counter (various)/counters.png" width="1600" height="3520"/>
</tileset>
