<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="Gather Logos 1.x" tilewidth="32" tileheight="32" tilecount="464" columns="29">
 <image source="gather_logos_1.0.png" width="928" height="512"/>
</tileset>
