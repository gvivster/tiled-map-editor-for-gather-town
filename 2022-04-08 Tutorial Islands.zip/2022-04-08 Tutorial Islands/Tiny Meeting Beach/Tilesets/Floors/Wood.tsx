<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Wood" tilewidth="32" tileheight="32" tilecount="8640" columns="180">
 <image source="Wood.png" width="5760" height="1536"/>
</tileset>
